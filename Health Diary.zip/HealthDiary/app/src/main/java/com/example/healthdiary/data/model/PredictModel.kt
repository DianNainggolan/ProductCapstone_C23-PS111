package com.example.healthdiary.data.model

import com.google.gson.annotations.SerializedName

data class Predict (
    @field:SerializedName("recommendation")
    val hasilPredict: String,
)