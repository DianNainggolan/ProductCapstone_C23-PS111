package com.example.healthdiary.viewModel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.aplikasisocialmedia.data.api.ApiConfig
import com.example.healthdiary.data.model.Predict
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PredictViewModel(val note: String) : ViewModel() {

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _hasilPredict = MutableLiveData<Predict>()
    val hasilPredict: LiveData<Predict> = _hasilPredict

    init {
        addNote(note)
    }

    fun addNote(note: String){
        _isLoading.value = true
        val client = ApiConfig.getApiService().addDiary(note)
        client.enqueue(object: Callback<Predict> {
            override fun onResponse(
                call: Call<Predict>,
                response: Response<Predict>
            ) {
                _isLoading.value = false
                println("ok ok")
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    _hasilPredict.value = responseBody!!
                }
            }
            override fun onFailure(
                call: Call<Predict>,
                t: Throwable
            ) {
                Log.e("Main Activity", "onFailure: ${t.message}")
            }

        })
    }
}