package com.example.healthdiary.view

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.healthdiary.data.model.Predict
import com.example.healthdiary.databinding.ActivityPredictBinding
import com.example.healthdiary.viewModel.PredictViewModel
import com.example.healthdiary.viewModel.PredictViewModelFactory

class PredictActivity : AppCompatActivity() {
    private lateinit var binding: ActivityPredictBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val note = intent.getStringExtra("diary").toString()

        val predictViewModel = ViewModelProvider(this, PredictViewModelFactory(note))[PredictViewModel::class.java]

        predictViewModel.hasilPredict.observe(this){ predict -> setPredict(predict)}

        predictViewModel.isLoading.observe(this){
            showLoading(it)
        }

        binding = ActivityPredictBinding.inflate(layoutInflater)
        setContentView(binding.root)

    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE

        } else {
            binding.progressBar.visibility = View.GONE

        }
    }
    
    private fun setPredict(predict: Predict){
        binding.hasilPredict.text = predict.hasilPredict
        binding.judul.text = "Prediksi Kesehatan Mental"
    }
}