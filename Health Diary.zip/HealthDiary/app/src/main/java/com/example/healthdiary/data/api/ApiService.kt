package com.example.healthdiary.data.api

import com.example.healthdiary.data.model.Predict
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface ApiService {
    @FormUrlEncoded
    @POST("adddiary")
    fun addDiary(
        @Field("diary") diary: String
    ): Call<Predict>
}